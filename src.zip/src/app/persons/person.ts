export interface Person {
  id: string;
  name: string;
  gender: string;
  description: string;
}
